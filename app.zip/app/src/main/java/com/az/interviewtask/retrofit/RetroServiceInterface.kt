package com.az.interviewtask.retrofit

import com.az.interviewtask.data.NewsModel
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path;

interface RetroServiceInterface {

    @GET("v0/topstories.json?print=pretty")
    fun getTopStories(): Call<List<Int>>

    @GET("v0/item/{articleid}.json?print=pretty")
    fun getArticle(@Path("articleid") id: Int): Call<NewsModel>
}