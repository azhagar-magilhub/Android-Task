package com.az.interviewtask.viewModel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.az.interviewtask.data.NewsModel
import com.az.interviewtask.data.NewsResponse
import com.az.interviewtask.retrofit.RetroInstance
import com.az.interviewtask.retrofit.RetroServiceInterface
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivityViewModel:ViewModel() {

    lateinit var liveDataList:MutableLiveData< List<NewsModel>>
    val list: ArrayList<NewsModel> = ArrayList()
    init {
        liveDataList = MutableLiveData()
    }

    fun getLiveDataObserver():MutableLiveData<List<NewsModel>>{
        return liveDataList
    }

    fun makeAPICall(){
        val retroInstance = RetroInstance().getRetroInstance()
        val retroService = retroInstance.create(RetroServiceInterface::class.java)
        val call = retroService.getTopStories()
        call.enqueue(object : Callback<List<Int>>{


            override fun onFailure(call: Call<List<Int>>, t: Throwable) {
                TODO("Not yet implemented")
            }

            override fun onResponse(call: Call<List<Int>>, response: Response<List<Int>>) {
                val topStories = response.body()


                for (i in 0..9) {
                    val callItem = retroService.getArticle(topStories!![i])
                    callItem.enqueue(object: Callback<NewsModel> {

                        override fun onFailure(callItem: Call<NewsModel>, t: Throwable) {}

                            override fun onResponse(
                                callItem: Call<NewsModel>,
                                response: Response<NewsModel>
                            ) {
                                Log.e("response",response.body().toString())
                                val title: String = "data title"
                                   // response.body().title.toString()
                                val url: String = "data url"
                                    //response.body().url.toString()

                                list.add(NewsModel("aaa","dfdfd"))
                            }

                        })
                }
                liveDataList.postValue(list)
                Log.e("liveDataList",liveDataList.toString())

            }
        }
        )
    }
}




//override fun onFailure(call: Call<List<Int?>>,t:Throwable){
//    // liveDataList.postValue((null))
//}
//
//override fun onResponse(
//    call: Call<List<Int?>>,
//    response: Response<List<Int?>>
//) {
//    // liveDataList.postValue(response.body())
//}

