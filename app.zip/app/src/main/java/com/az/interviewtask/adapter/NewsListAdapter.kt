package com.az.interviewtask.adapter

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.az.interviewtask.R
import com.az.interviewtask.data.NewsModel
import kotlinx.android.synthetic.main.news_list_row.view.*

class NewsListAdapter(val activity : Activity) : RecyclerView.Adapter<NewsListAdapter.MyViewHolder>() {

    private var newsList: List<NewsModel>? = null

    fun setNewsList(newsList: List<NewsModel>?) {
        this.newsList = newsList

    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): NewsListAdapter.MyViewHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.news_list_row, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: NewsListAdapter.MyViewHolder, position: Int) {
        holder.bind(newsList?.get(position)!!, activity)
    }

    override fun getItemCount(): Int {
        if (newsList == null) return 0
        else return newsList?.size!!
    }

    class MyViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val textview = view.textview

        fun bind(data: NewsModel, activity: Activity) {
            textview.text = data.title

        }
    }
}