package com.az.interviewtask.data

data class NewsModel(
    val title: String?,
    val url: String?,
)
